#include "$safeitemname$.h"
#include <ecs_prj/Entity.h>

namespace K_Engine {
	//Required
	std::string $safeitemname$::name = "$safeitemname$";

	std::string $safeitemname$::GetId() {
		return name;
	}

	$safeitemname$::$safeitemname$(Entity* e) : Component(e) {
		
	}

	$safeitemname$::$safeitemname$() : Component(e) {
	
	}

	$safeitemname$::~$safeitemname$() = default;

	void $safeitemname$::start() {

	}

	void $safeitemname$::update(int frameTime) {

	}
}
