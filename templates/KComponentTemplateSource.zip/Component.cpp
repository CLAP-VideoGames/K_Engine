#include "$safeitemname$.h"
#include <ecs_prj/Entity.h>

namespace K_Engine {
	//Required
	std::string $safeitemname$::name = "$safeitemname$";

	$safeitemname$::$safeitemname$(Entity* e) : Component("$safeitemname$", e) {
		name = id;
	}
}
